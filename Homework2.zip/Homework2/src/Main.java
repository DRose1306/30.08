import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {
        int myInt1 = 345;
        int a = myInt1 / 100;
        int b = myInt1 / 10 % 10;
        int c = myInt1 % 100 % 10;
        System.out.print("Число 345 -> ");
        System.out.print(a + ", " + b + ", " + c);
        System.out.println(" ");
        int myInt2 = 987;
        int a2 = myInt2 / 100;
        int b2 = myInt2 / 10 % 10;
        int c2 = myInt2 % 100 %10;
        System.out.print("Число 987 -> ");
        System.out.print(a2 + ", " + b2 + ", " + c2);

    }
}
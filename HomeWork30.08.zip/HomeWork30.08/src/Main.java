public class Main {
    public static void main(String[] args) {
        // Homework#1
        char myLetter = 'G';
        int a = 89;
        byte b = 4;
        short c = 56;
        float d = 4.7333436f;
        double e = 4.355453532;
        long f = 12121;
        System.out.printf(
                """
                \tchar: %s
                \tint: %d
                \tbyte: %d
                \tshort: %d
                \tfloat: %f
                \tdouble: %f
                \tlong: %d
                """,
                'G',
                a,
                b,
                c,
                d,
                e,
                f
                );
    }
}
